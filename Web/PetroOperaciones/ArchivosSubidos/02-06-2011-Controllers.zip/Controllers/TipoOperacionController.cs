﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PetroOperaciones.Models;

namespace PetroOperaciones.Controllers
{ 
    public class TipoOperacionController : Controller
    {
        private PetroOperacionesContext db = new PetroOperacionesContext();

        //
        // GET: /TipoOperacion/

        public ViewResult Index()
        {
            return View(db.TipoOperacions.ToList());
        }

        //
        // GET: /TipoOperacion/Details/5

        public ViewResult Details(int id)
        {
            TipoOperacion tipooperacion = db.TipoOperacions.Find(id);
            return View(tipooperacion);
        }

        //
        // GET: /TipoOperacion/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /TipoOperacion/Create

        [HttpPost]
        public ActionResult Create(TipoOperacion tipooperacion)
        {
            if (ModelState.IsValid)
            {
                db.TipoOperacions.Add(tipooperacion);
                db.SaveChanges();
                return RedirectToAction("Index");  
            }

            return View(tipooperacion);
        }
        
        //
        // GET: /TipoOperacion/Edit/5
 
        public ActionResult Edit(int id)
        {
            TipoOperacion tipooperacion = db.TipoOperacions.Find(id);
            return View(tipooperacion);
        }

        //
        // POST: /TipoOperacion/Edit/5

        [HttpPost]
        public ActionResult Edit(TipoOperacion tipooperacion)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tipooperacion).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tipooperacion);
        }

        //
        // GET: /TipoOperacion/Delete/5
 
        public ActionResult Delete(int id)
        {
            TipoOperacion tipooperacion = db.TipoOperacions.Find(id);
            return View(tipooperacion);
        }

        //
        // POST: /TipoOperacion/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {            
            TipoOperacion tipooperacion = db.TipoOperacions.Find(id);
            db.TipoOperacions.Remove(tipooperacion);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}